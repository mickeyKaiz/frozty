<h1>Frozty</h1>
<h3>Simple PHP Framework</h3>

<a href="math">Math</a>
<ul>
    <li><a href="math/add">Addition</a></li>
    <li><a href="math/substract">Substraction</a></li>
    <li><a href="math/multiply">Multiplication</a></li>
</ul>
        