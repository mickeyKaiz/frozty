<div class="card">
    <div class="container">
        <h3>FROZTY FRAMEWORK</h3>
    </div>
</div>